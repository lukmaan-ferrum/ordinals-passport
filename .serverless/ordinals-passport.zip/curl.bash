curl -X POST http://localhost:3000/dev/admin/vrf/bulkUpload   \
-H "Content-Type: application/json" \
-d @sampleVRFs.json

curl -X POST http://localhost:3000/dev/vrf/12454741948589683358695376253003350026281153291808990050389167476596461939757/update/web3Name \
-H "Content-Type: application/json" \
-d '{
  "web3Name": "satoshi"
}'


# encode imagge to base64. Frontend will need to do this
base64 -i pfp.jpg -o pfp_base64.txt

# Test
BASE64_IMAGE=$(cat pfp_base64.txt)
curl -X POST "http://localhost:3000/dev/vrf/59866181108749426618976898127596939798847318118004127514311014136857891769344/update/pfp" \
  -H "Content-Type: application/json" \
  -d "{\"image\":\"${BASE64_IMAGE}\", \"filename\":\"pfp.jpg\", \"mimetype\":\"image/jpeg\"}"